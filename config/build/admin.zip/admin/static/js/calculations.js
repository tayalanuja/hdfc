$(document).ready(function() {
  const download_CSV = sessionStorage.getItem('download_CSV');
  const bank_name = sessionStorage.getItem('bank_name');
  const bank_type = sessionStorage.getItem('bank_type');
  const word_order = sessionStorage.getItem('word_order');
  const text = JSON.parse(sessionStorage.getItem('text'));


  const file_path = sessionStorage.getItem('file_path');

  // var data_attrs2 = [{ "bank_name": bank_name }, { "csv_path": download_CSV }, { "bank_type": bank_type }, { "file_path": file_path },{ "text": text },{"word_order":word_order}]
  //   let data_attrs2 = [{'bank_name': bank_name, 'csv_path': download_CSV, 'bank_type': bank_type, 'file_path': file_path,'text': text,'word_order': word_order}];

  // var download_CSV = sessionStorage.getItem("download_CSV")
  $('#downloadCSV').attr('href', download_CSV);


  const url_string = window.location.href;
  const url = new URL(url_string);
  const job_id = url.searchParams.get('job_id');
  console.log(job_id);

  $('#upload_documents').attr('href', 'dashboard.html?job_id='+job_id);
  $('#localization').attr('href', 'localization.html?job_id='+job_id);
  $('#digitization').attr('href', 'table_digitization.html?job_id='+job_id);
  $('#download').attr('href', 'download_data.html?job_id='+job_id);
  $('#calcutions').attr('href', 'calculations.html?job_id='+job_id);

  const token = sessionStorage.getItem('token');

  const data_attrs2 = {
    'token': token,
    'job_id': job_id,
  };


  const success = {
    'url': 'https://credit.in-d.ai/hdfc/credit/calculations_result',
    'headers': {
      'content-type': 'application/json',
    },
    'method': 'POST',
    'processData': false,
    'data': JSON.stringify(data_attrs2),
  };

  $.ajax(success).done(function(data, textStatus, xhr) {
    if (xhr.status === 200) {
      console.log(data);
      console.log(data.result);
      // console.log("data.result['Total amount spent through payment gateways']", data.result['Total amount spent through payment gateways']);
      // console.log("data.result[0]",data.result[0]);
      $('#downloadCSV2').attr('href', data.calculation_csv_path);

      $.each(data.result, function(key, value) {
      // console.log(object)
        console.log(key);
        console.log(value);

        $('#data_table').append('<tr><td><strong>' + key + '</strong></td><td>' + value + '</td></tr>');
      });


      $('#total_debit').text(data.result['14. Total amount debited']);
      $('#total_credited').text(data.result['13. Total amount credited']);


      $('.account_holder').text(data.result['01. Account Holder']);
      $('.account_number').text(data.result['02. Account Number']);
      $('.Statement_start_date').text(data.result['03. Statement Start Date']);
      $('.Statement_end_date').text(data.result['04. Statement End Date']);
      $('.opening_balance').text(data.result['09. Opening Balance']);
      $('.total_amount_debited').text(data.result['14. Total amount debited']);
      $('.total_amount_credit').text(data.result['13. Total amount credited']);
      $('.closing_balance').text(data.result['10. Closing Balance']);

      const credit_sub_total = data.result['32. Total amount credited through salary'] + data.result['40. Total amount credited through cheque'] + data.result['20. Total amount credited through UPI'] + data.result['24. Total amount credited through net banking'] + data.result['16. Total amount of cash deposited'];
      // alert(debit_sub_total)
      const total_amount_credit_chart = data.result['13. Total amount credited'] - credit_sub_total;

      const oilCanvas = document.getElementById('myChart');
      var oilData = {
        labels: [
          'Cheque',
          'UPI',
          'Net Banking',
          'Cash Deposit',
          'Salary',
          'Other',
        ],
        datasets: [
          {
            data: [
              data.result['40. Total amount credited through cheque'],
              data.result['20. Total amount credited through UPI'],
              data.result['24. Total amount credited through net banking'],
              data.result['16. Total amount of cash deposited'],
              data.result['32. Total amount credited through salary'],
              total_amount_credit_chart,
            ],
            backgroundColor: [
              '#FF6384',
              '#f3d2ba',
              '#84FF63',
              '#392be891',
              '#67d6c3',
            ],
          }],
      };

      var pieChart = new Chart(oilCanvas, {
        type: 'pie',
        data: oilData,
      });

      const debit_sub_total = data.result['38. Total amount debited through cheque'] + data.result['22. Total amount debited through UPI'] + data.result['26. Total amount debited through net banking'] + data.result['18. Total amount of cash withdrawed'] + data.result['66. Total amount spent at merchant outlets'];
      // alert(debit_sub_total)
      const total_amount_chart = data.result['14. Total amount debited'] - debit_sub_total;

      const debit_chart = document.getElementById('debit_chart');
      var oilData = {
        labels: [
          'Cheque',
          'UPI',
          'Net Banking',
          'Cash Withdraw',
          'Merchant Outlets',
          'Other',
        ],
        datasets: [
          {
            data: [
              data.result['38. Total amount debited through cheque'],
              data.result['22. Total amount debited through UPI'],
              data.result['26. Total amount debited through net banking'],
              data.result['18. Total amount of cash withdrawed'],
              data.result['66. Total amount spent at merchant outlets'],
              total_amount_chart,
            ],
            backgroundColor: [
              '#FF6384',
              '#f3d2ba',
              '#84FF63',
              '#392be891',
              '#67d6c3',
            ],
          }],
      };
      var pieChart = new Chart(debit_chart, {
        type: 'pie',
        data: oilData,
      });

      const ctx11 = document.getElementById('myChart11').getContext('2d');

      const myChart11 = new Chart(ctx11, {
        type: 'line',
        data: {
          labels: ['Jan',	'Feb',	'Mar',	'Apr',	'May',	'June',	'July', 'Aug',	'Sept', 'Oct', 'Nov', 'Dec'],
          datasets: [{
            label: 'Monthly Average Balance', // Name the series
            data: [5056,	88942,	64545,	50001,	45555,	36516,	22224,	5504, 14629, 4545, 1417, 15504], // Specify the data values array
            fill: false,
            borderColor: '#4CAF50', // Add custom color border (Line)
            backgroundColor: '#4CAF50', // Add custom color background (Points and Fill)
            borderWidth: 1, // Specify bar border width
          }],
        },
        options: {
          responsive: true, // Instruct chart js to respond nicely.
          maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
        },
      });


      const densityCanvas = document.getElementById('densityChart');

      const number_debit_other_sub = data.result['21. Number of UPI debit transactions'] + data.result['25. Number of net banking debit transactions'] + data.result['37. Number of debit transactions through cheque'] + data.result['17. Number of cash withdrawal transactions'];
      const number_debit_other = data.result['12. Number of debit transactions'] - number_debit_other_sub;
      console.log('number_debit_other', number_debit_other);
      console.log('data.result[\'12. Number of debit transactions\']  -  number_debit_other_sub', data.result['12. Number of debit transactions'] - number_debit_other_sub);
      // var number_credit_other = ;

      const number_credit_other_sub = data.result['19. Number of UPI credit transactions'] + data.result['23. Number of net banking credit transactions'] + data.result['39. Number of credit transactions through cheque'] + data.result['15. Number of cash deposit transactions'];
      const number_credit_other = data.result['11. Number of credit transactions'] - number_credit_other_sub;

      console.log('data.result[\'11. Number of credit transactions\']  -  number_credit_other_sub', data.result['12. Number of debit transactions'] - number_credit_other_sub);
      const densityData = {
        label: 'Debit : ' + data.result['12. Number of debit transactions']+'',
        data: [
          data.result['21. Number of UPI debit transactions'],
          data.result['25. Number of net banking debit transactions'],
          data.result['37. Number of debit transactions through cheque'],
          data.result['17. Number of cash withdrawal transactions'],
          number_debit_other,


        // data.result['Total amount debited']
        ],
        backgroundColor: 'rgba(0, 99, 132, 0.6)',
        borderWidth: 0,
        yAxisID: 'y-axis-density',
      };

      const gravityData = {
        label: 'Credit : ' + data.result['11. Number of credit transactions']+'',
        data: [
          data.result['19. Number of UPI credit transactions'],
          data.result['23. Number of net banking credit transactions'],
          data.result['39. Number of credit transactions through cheque'],
          data.result['15. Number of cash deposit transactions'],
          number_credit_other,
        ],
        backgroundColor: 'rgba(99, 132, 0, 0.6)',
        borderWidth: 0,
        yAxisID: '',
      };

      const planetData = {
        labels: ['UPI', 'Net Banking', 'Cheque', 'Cash', 'Others'],
        datasets: [densityData, gravityData],
      };

      const chartOptions = {
        scales: {
          xAxes: [{
            barPercentage: 1,
            categoryPercentage: 0.6,
          }],
          yAxes: [{
            id: 'y-axis-density',
          }],
        },
      };

      const barChart = new Chart(densityCanvas, {
        type: 'bar',
        data: planetData,
        options: chartOptions,
      });
    } else if (xhr.status === 201) {
      alert(JSON.stringify(data.message));
      location.reload();
    } else {
      alert(JSON.stringify(data.message));
      location.reload();
    }
  }).fail(function(data) {
    console.log('data', data);
  });

  $('#BtnUpdatetableDetaills').click(function() {
    sessionStorage.removeItem('table_data');

    setTimeout(function() {
      window.location.href = 'calculations.html';
    }, 1000);
  });
});
