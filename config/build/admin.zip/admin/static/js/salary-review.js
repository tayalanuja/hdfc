$(document).ready(function () {
    sessionStorage.removeItem('table_coords');
    sessionStorage.removeItem('table_data');

    // $(document).ajaxStart(function () {
    //     $("#wait2").css("display", "block");
    // });

    // $(document).ajaxComplete(function () {
    //     $("#wait2").css("display", "none");
    // });

    $('.imagePlaceholer').hide();

    const url_string = window.location.href;
    const url = new URL(url_string);
    const job_id = url.searchParams.get('job_id');
    const emailid = url.searchParams.get('emailid');
    console.log(job_id + " emailid " + emailid);

    $('#upload_documents').attr('href', 'dashboard-salaryslip.html?job_id=' + job_id);
    $('#localization').attr('href', 'localization.html?job_id=' + job_id);
    $('#digitization').attr('href', 'table_digitization.html?job_id=' + job_id);
    $('#download').attr('href', 'download_data.html?job_id=' + job_id);
    $('#calcutions').attr('href', 'calculations.html?job_id=' + job_id);

    const token = sessionStorage.getItem('token');
    const data_attrs = {
        'token': token,
        'job_id': job_id,
        'user_email': emailid,

    };

    doc_attributes(data_attrs);

});

// if ("localization_data" in sessionStorage) {

//     data = sessionStorage.getItem("localization_data");
//     // console.log("data", data);

//     data = JSON.parse(data);
//     doc_attributes_function(data);


// } else {
//     // alert("No");

//     sessionStorage.removeItem("file_path");

//     var data_attrs = {
//         "token": token,
//         "password": password,

//     };

//     var success2 = {
//         "url": "check_password",
//         "headers": {
//             "content-type": "application/json"
//         },
//         "method": "POST",
//         "processData": false,
//         "data": JSON.stringify(data_attrs)
//     }

//     $("#showPopup").hide();
//     $.ajax(success2).done(function (data) {
//         sessionStorage.setItem("file_path", data.file_path);
//         console.log("check password done", data.result)
//         if (data.result === true) {
//             doc_attributes(data);

//         } else {
//             $('#myModal').modal('show');
//             $("#showPopup").show();
//         }

//     }).fail(function (data) {
//         console.log("check password error", data)
//     });

// };

// $('#getpasswordBtn').click(function () {
//     $('#popupMessage').show();
//     setTimeout(function () {
//         $('#myModal').modal('hide');
//         $('.modal-backdrop').hide();

//     }, 1500);


//   let data = {
//     'file_path': sessionStorage.getItem('file_path'),
//     'doc_type': sessionStorage.getItem('doc_type'),
//     'bank_name': sessionStorage.getItem('bank_name'),
//     'readable_status': sessionStorage.getItem('readable_status'),
//   };

// //   doc_attributes(data);


// eslint-disable-next-line require-jsdoc
function doc_attributes(data_attrs) {

    $('#wait3').css('display', 'block');

    console.log('doc_attributes', JSON.stringify(data_attrs));

    const success = {
        'url': 'https://credit.in-d.ai/hdfc/payslip/admin_review_job',
        'headers': {
            'content-type': 'application/json',
        },
        'method': 'POST',
        'processData': false,
        'data': JSON.stringify(data_attrs),
    };

    $.ajax(success).done(function (data, textStatus, xhr) {
        // alert("HI")

        if (xhr.status === 200) {
            sessionStorage.setItem('localization_data', JSON.stringify(data));
            doc_attributes_function(data);
        } else if (xhr.status === 201) {
            alert(data.message);
        } else {

        }
    }).fail(function (data) {
        console.log('data', data);
        $('.imagePlaceholer').show();

        if (data.responseJSON.message == 'Not successful!') {

        };

        if (data.responseJSON.message == 'Token is invalid!') {
            $('#error').show();
            $('#error').text('Session expired, It will redirect to login page.', data.responseJSON.message);

            setTimeout(function () {
                window.location.href = 'index.html';
            }, 2000);
            sessionStorage.removeItem('token');
            sessionStorage.clear();
        };
    });
};


function doc_attributes_function(data) {
    $('#wait2').css('display', 'none');
    $('#wait3').css('display', 'none');
    $('.imagePlaceholer').show();
    console.log('doc_attributes_function', data.result.length);
    console.log('doc_attributes_function', data.result);

    const imageHeight = data['height'] + 5;
    const imagewidth = data['width'];
    const readable_status = data['readable_status'];
    const reduced_percentage = data['reduced_percentage'];
    data = data.result;
    const No_Quotes_string = eval(data);
    console.log('No_Quotes_string', No_Quotes_string);



    CreateMenu(No_Quotes_string)

    const newinputs= []
    newinputs.push(No_Quotes_string[0])

    CreateInputs(newinputs, imageHeight, imagewidth)

    

    
}

function filterDataItem(data){
    alert(data)
}

function CreateInputs(No_Quotes_string, imageHeight, imagewidth){
    $.each(No_Quotes_string, function (obj, key, i) {
        console.log('key.email_id', key.email_id);
        console.log('key.image_path', key.image_path);

        console.log('key.file_name', key.file_name);
        // menuItem.push({"file_name":key.file_name, "email_id":key.email_id})


        console.log('key.inv_level_conf', key.inv_level_conf);
        // console.log('key.table_data.top', key.fields[0].Result);
        const section = $('<div class=\'items row ' + obj + '\' style=\'position:relative; padding:25px 0px; margin:0px; border:0px; height:' + imageHeight + 'px;width:' + imagewidth + 'px\' />');
        $(section).append('<div class=\'images col-7 col-md-7 \'> <img src=\'https://credit.in-d.ai/hdfc/' + key.image_path + '\' /> <input  name=\'item' + obj + '.bankname\' value=\'' + key.bank_name + ' \' /> <input  name=\'item' + obj + '.documentType\' value=\'' + key.documentType + '\' /> <input   name=\'item' + obj + '.corrected_imageName\' value=\'' + key.image_path + ' \' /> </div>');

        const table = $('<div class=\'table col-5 col-md-5\'/>');

        $.each(key.fields[0].Result, function (rowIndex, key, object, value) {
            // console.log('rowIndex + rowIndex', rowIndex);
            // console.log('rowIndex + key', key);
            // console.log('rowIndex + object', object);
            // console.log('rowIndex + value', value);

            var row = $('<div class="form-group"></div>');
            row.append($(`
                <label for="exampleInputEmail1">${key.label}</label>
                <input type="text"  class="form-control"  value="${key.value}" name="${key.label}" />
            `));
            // $.each(key, function (key, object, value, i) {
            //     // console.log('object', object);
            //     // console.log('key', key);
            //     // row.append('asasd')
            //     row.append($(`<div class=''>${key.confidence_score} </div>`));
            // });
            table.append(row);
        });
        // tableDiv.append(table);
        // if (obj == 0) {
        //     const buttontop = key.table_data[0].top - 100;
        //     console.log('key.table_data.top', buttontop);
        //     section.append('<div class=\'add btn btn-warning\' style=\'position:absolute; top:' + buttontop + 'px;\'>Add Column</div> <div style=\'display:none\' id=\'theCount\'></div>');
        // }

        section.append(table);
        section.append('<div class=\'clearfix\'/>');
        $('#localization_multicol').append(section);
    });
}


function CreateMenu(No_Quotes_string){

    let menuItem = $('<div class="menuItem"></div>')

    $.each(No_Quotes_string, function (obj, key, i) {
        console.log('key.email_id', key.email_id);
        console.log('key.image_path', key.image_path);

        console.log('key.file_name', key.file_name);
        // menuItem.push({"file_name":key.file_name, "email_id":key.email_id})

        menuItem.append($(`
                <div class="menuItemLink" data-text="${key.file_name}">${key.file_name}</label>
            `));

        });
        console.log("menuItem", menuItem)
        $("#menuWrapper").append(menuItem)

        $( ".menuItemLink").click(function() {
          const text = $(this).attr("data-text")
          alert(text)
           
          });
    
}



$('#wait5').hide();
$('#BtnUpdateLocalizations').click(function () {
    $('#wait5').show();
    const url_string = window.location.href;
    const url = new URL(url_string);
    const job_id = url.searchParams.get('job_id');
    console.log(job_id);

    const obj = $('#updateLocalizations').serializeToJSON({
        parseFloat: {
            condition: '.number,.money',
        },
        useIntKeysAsArrayIndex: true,
    });
    console.log(obj);
    const jsonString = obj;
    console.log(jsonString);
    sessionStorage.setItem('table_coords', JSON.stringify(jsonString));
    $('#result').val(jsonString);
    setTimeout(function () {
        window.location.href = 'table_digitization.html?job_id=' + job_id;
    }, 3000);
});

// });
