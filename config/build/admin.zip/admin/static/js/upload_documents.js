$(document).ready(function () {
    var token = sessionStorage.getItem("token");
    document.getElementById("token2").value = sessionStorage.getItem("token");
});